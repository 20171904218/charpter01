package model.auction.dao.impl;

import java.util.ArrayList;

import model.Good;
import model.auction.dao.GoodDAO;

public class GoodDAOImpl implements GoodDAO{

	@Override
	public ArrayList<Good> getGoodList() {
		// TODO Auto-generated method stub
		ArrayList<Good> list = new ArrayList<Good>();
		for(int i=0;i<10;i++){
			Good good = new Good("��Ʒ"+i,i,1);
			list.add(good);
		}
		return list;
	}

}
