package model;

public class Good {

	private String name;
	private float price;
	private int number;
	public Good() {
		super();
	}
	public Good(String name, float price, int number) {
		super();
		this.name = name;
		this.price = price;
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
