package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Good;
import model.Person;
import model.auction.dao.impl.ShoppingCarDAOImpl;
@WebServlet("/personShopping")
public class PersonShoppingServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		float price = Float.parseFloat(request.getParameter("price"));
		int number = Integer.parseInt(request.getParameter("number"));
		String description = request.getParameter("description");
		System.out.println("name === "+name);
		System.out.println("price === "+price);
		System.out.println("number === "+number);
		System.out.println("description === "+description);
		Good good = new Good(name,price,number,description);
		//��û�е�¼
		Person person = (Person)request.getSession().getAttribute("person");
		//û�е�¼�͹�����
		if(person == null){
			ArrayList<Good> tempShoppingCarList = (ArrayList<Good>) request.getSession().getAttribute("tempShoppingCarList");
			if(tempShoppingCarList == null){
				tempShoppingCarList = new ArrayList<Good>();
			}
			tempShoppingCarList.add(good);
			request.getSession().setAttribute("tempShoppingCarList", tempShoppingCarList);
			request.setAttribute("shoppingInfo", name+"������ʱ���ﳵ�ɹ�");
			request.getRequestDispatcher("/allGoodsToShoppingView").forward(request, response);
			return;
		}else{//��¼��,�����ڹ���
			new ShoppingCarDAOImpl().addGood(person.getName(), good);
			request.setAttribute("shoppingInfo", name+"�����ҵĹ��ﳵ�ɹ�");
			request.getRequestDispatcher("/allGoodsToShoppingView").forward(request, response);
			return;
		}
	}

}
