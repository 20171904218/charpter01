package controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Good;
import model.Person;
import model.auction.dao.impl.PersonDAOImpl;
import model.auction.dao.impl.ShoppingCarDAOImpl;
@WebServlet("/personLogin")
public class PersonLoginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String isAuto = request.getParameter("autoLogin");
		System.out.println("name==="+name);
		System.out.println("password==="+password);
		String error = (new PersonDAOImpl().isLogin(name, password));
		//errorΪ"",��¼�ɹ�,������ʱ���ﳵ�е�������Ʒ�������ݿ��еĹ��ﳵ��
		if("".equals(error)){
			HttpSession session = request.getSession();
			session.setAttribute("person", new Person(name,password));
			ArrayList<Good> tempShoppingCarList = (ArrayList<Good>) request.getSession().getAttribute("tempShoppingCarList");
			if(tempShoppingCarList != null){
				for(int i = 0;i < tempShoppingCarList.size();i++){
					Good good = tempShoppingCarList.get(i);
					new ShoppingCarDAOImpl().addGood(name, good);
				}
			}
		}
		if("".equals(error)||"on".equals(isAuto)){
			Cookie cookie = new Cookie("name-password",name+"-"+password);
			//һ�����Զ���¼
			cookie.setMaxAge(1*60);
			response.addCookie(cookie);
			//��ҳ
			request.getRequestDispatcher("/function.jsp").forward(request, response);
			return;
		}else{
			//���ش�����Ϣ����¼ҳ
			request.setAttribute("error", error);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}

}
