package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Person;
import model.auction.dao.impl.PersonDAOImpl;
@WebServlet("/getPersonInfo")
public class GetPersonInfoServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Person person = (Person) request.getSession().getAttribute("person");
		if(person != null){//�Ѿ���¼�ɹ������Դ����ݿ���ȡ����Ϣ
			Person personInfo = new PersonDAOImpl().getPersonInfo(person.getName());
			request.setAttribute("personInfo", personInfo);
			request.getRequestDispatcher("/personInfoShow.jsp").forward(request, response);
		}else{
			request.setAttribute("error", "���ȵ�¼���ٲ鿴������Ϣ");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}

	}

}
