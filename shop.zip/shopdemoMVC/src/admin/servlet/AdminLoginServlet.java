package admin.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import admin.dao.impl.AdminDAOImpl;
import admin.entity.Admin;
import model.auction.dao.impl.PersonDAOImpl;
@WebServlet("/adminLogin")
public class AdminLoginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String error = (new AdminDAOImpl().isLogin(name, password));
		if("".equals(error)){
			request.getSession().setAttribute("admin", new Admin(name, password));;
			request.getRequestDispatcher("/admin/adminFunction.jsp").forward(request, response);
			return;
		}else{
			//���ش�����Ϣ����¼ҳ
			request.setAttribute("error", error);
			request.getRequestDispatcher("/admin/login.jsp").forward(request, response);
		}
	}

}
