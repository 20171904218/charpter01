package admin.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBUtil;
import model.Good;
import model.auction.dao.impl.GoodDAOImpl;
import admin.dao.AdminDAO;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public String isLogin(String name, String password) {
		// TODO Auto-generated method stub
		if("".equals(name)||"".equals(password)){
			return "�û���������Ϊ��";
		}
		String error = null;
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "select * from admin where name=? and password=?;";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 ps.setString(2, password);
				 rs = ps.executeQuery();
				 if(rs.next()){
					 error =  "";
				 }else{
					 error = "�û�����������д����";
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
	        return error;
	}

	@Override
	public String addGood(Good good) {
		// TODO Auto-generated method stub
		String error = "";
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "insert into goods(name,price,number,description) values(?,?,?,?);";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, good.getName());
				 ps.setFloat(2, good.getPrice());
				 ps.setInt(3, good.getNumber());
				 ps.setString(4, good.getDescription());
				 int n = ps.executeUpdate();
				 if(n <= 0){
					 error = "��Ʒ"+good.getName()+"����ʧ��";
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
	        return error;
	}

	@Override
	public String deleteGood(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String modifyGood(Good good) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Good> lookAllGoods() {
		// TODO Auto-generated method stub
		return new GoodDAOImpl().getGoodList();
	}

}
