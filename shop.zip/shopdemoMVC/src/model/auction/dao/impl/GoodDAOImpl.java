package model.auction.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBUtil;
import model.Good;
import model.auction.dao.GoodDAO;

public class GoodDAOImpl implements GoodDAO{

	//�����ݿ��ж�����Ʒ�б�
	@Override
	public ArrayList<Good> getGoodList() {
		// TODO Auto-generated method stub
		ArrayList<Good> list = new ArrayList<Good>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Good good = null;
        String sql = "select * from goods";
        conn = DBUtil.getConn();
        try {
			ps = conn.prepareStatement(sql);
			 rs = ps.executeQuery();
			 while(rs.next()){
				 good = new Good(rs.getString(1), rs.getFloat(2), rs.getInt(3), rs.getString(4));
				 list.add(good);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DBUtil.closeAll(conn, ps, rs);
		}
		return list;
	}

}
