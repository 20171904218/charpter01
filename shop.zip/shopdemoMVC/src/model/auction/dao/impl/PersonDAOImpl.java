package model.auction.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBUtil;
import model.Good;
import model.Person;
import model.auction.dao.PersonDAO;

public class PersonDAOImpl implements PersonDAO {

	@Override
	public String isLogin(String name,String password) {
		// TODO Auto-generated method stub
		if("".equals(name)||"".equals(password)){
			return "�û���������Ϊ��";
		}
		String error = null;
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "select name,password from person where name=? and password=?;";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 ps.setString(2, password);
				 rs = ps.executeQuery();
				 if(rs.next()){
					 error =  "";
				 }else{
					 error = "�û�����������д����";
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
	        return error;
	}

	@Override
	public Person getPersonInfo(String name) {
		// TODO Auto-generated method stub
		Person person = null;
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "select * from person where name=?;";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 rs = ps.executeQuery();
				 if(rs.next()){
					 person = new Person(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4),
							 rs.getString(5),rs.getString(6),rs.getString(7));
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
		return person;
	}

}
