package model.auction.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import util.DBUtil;
import model.Good;
import model.auction.dao.ShoppingCarDAO;

public class ShoppingCarDAOImpl implements ShoppingCarDAO {
	
	//��name�õ����ݿ��й��ﳵ�е���Ʒ
	@Override
	public ArrayList<Good> getShoppingCar(String name) {
		// TODO Auto-generated method stub
		ArrayList<Good> goodList = new ArrayList<Good>();
		Good good = null;
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "select good_name,good_price,good_number,good_description from shoppingcar where owner_name=?;";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 rs = ps.executeQuery();
				 while(rs.next()){
					 good = new Good(rs.getString(1),rs.getFloat(2),rs.getInt(3),rs.getString(4));
					 goodList.add(good);
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
		return goodList;
	}
	//���빺�ﳵ��Ʒ
	@Override
	public String addGood(String name, Good good) {
		// TODO Auto-generated method stub
		String error = "";
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "insert into shoppingcar(owner_name,good_name,good_price,good_number,good_description) "+
	        "values(?,?,?,?,?);";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 ps.setString(2, good.getName());
				 ps.setFloat(3, good.getPrice());
				 ps.setInt(4, good.getNumber());
				 ps.setString(5, good.getDescription());
//				 rs = ps.executeQuery();
				 int n = ps.executeUpdate();
				 if(n <= 0){
					 error = "��Ʒ"+good.getName()+"����ʧ��";
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
		return error;
	}
	@Override
	public String deleteGood(String name,String good_name) {
		// TODO Auto-generated method stub
		String error = "";
	       Connection conn = null;
	        PreparedStatement ps = null;
	        ResultSet rs = null;
	        String sql = "delete from shoppingcar where owner_name=? and good_name=?;";
	        conn = DBUtil.getConn();
	        try {
				ps = conn.prepareStatement(sql);
				 ps.setString(1, name);
				 ps.setString(2, good_name);
//				 rs = ps.executeQuery();
				 int n = ps.executeUpdate();
				 if(n <= 0){
					 error = "��Ʒ"+good_name+"ɾ��ʧ��";
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DBUtil.closeAll(conn, ps, rs);
			}
		return error;
	}

}
