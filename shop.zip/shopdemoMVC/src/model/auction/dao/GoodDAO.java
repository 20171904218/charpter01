package model.auction.dao;

import java.util.ArrayList;

import model.Good;

public interface GoodDAO {

	public ArrayList<Good> getGoodList();
}
