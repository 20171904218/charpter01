package model.auction.dao;

import model.Person;

public interface PersonDAO {

	//�û���¼
	public String isLogin(String name,String password);
	//ͨ��name�õ���Ϣ
	public Person getPersonInfo(String name);
}
