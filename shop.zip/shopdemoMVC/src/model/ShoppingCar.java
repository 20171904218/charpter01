package model;

import java.util.ArrayList;

public class ShoppingCar {

	private ArrayList<Good> list;

	public ShoppingCar() {
		super();
	}

	public ShoppingCar(ArrayList<Good> list) {
		super();
		this.list = list;
	}

	public ArrayList<Good> getList() {
		return list;
	}

	public void setList(ArrayList<Good> list) {
		this.list = list;
	}
	
}
