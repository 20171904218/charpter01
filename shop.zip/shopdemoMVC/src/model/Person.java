package model;

public class Person {

	private String name;
	private String password;
	private String gender;
	private int age;
	private String school;
	private String major;
	private String tech;
	public Person() {
		super();
	}
	
	public Person(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}

	public Person(String name, String password, String gender, int age,
			String school, String major, String tech) {
		super();
		this.name = name;
		this.password = password;
		this.gender = gender;
		this.age = age;
		this.school = school;
		this.major = major;
		this.tech = tech;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getTech() {
		return tech;
	}
	public void setTech(String tech) {
		this.tech = tech;
	}
	
}
